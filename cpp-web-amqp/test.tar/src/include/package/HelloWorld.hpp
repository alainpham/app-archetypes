#include <iostream>

class HelloWorld
{
public:
    void say();
};