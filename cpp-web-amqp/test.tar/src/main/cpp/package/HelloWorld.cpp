#include "HelloWorld.hpp"

void HelloWorld::say()
{
    std::cout << "Hello, World" << std::endl;
}